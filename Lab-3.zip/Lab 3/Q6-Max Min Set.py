# Omer Mustafa - F2016-472
# Artificial Intelligence by Dr. Iftikhar Hussain
# Lab no. 3 - Question no.6
# Write a Python program to find maximum and the minimum value in a set.

#Create a set
seta = set([5, 10, 3, 15, 2, 20])
#Find maximum value
print(max(seta))
#Find minimum value
print(min(seta))
